--------------------------------------------------------------------------
-- * BMC Software, Inc.
-- * Confidential and Proprietary
-- * Copyright (c) BMC Software, Inc. 2013
-- * All Rights Reserved.
--------------------------------------------------------------------------
-- FILE NAME: enableWarningFlag.sql
--------------------------------------------------------------------------
--  Run this script as the SCHEMA_LOGIN against the SCHEMA_INSTANCE on the portal datastore host (SCHEMA_HOST) as defined in
--  the following file from your portal host:
--
--   %BMC_PORTAL_KIT_HOME%\BMCPortalKitInstalledConfiguration.xml  (on Windows)
--   $BMC_PORTAL_KIT_HOME\BMCPortalKitInstalledConfiguration.xml  (on Solaris)
--
--  Like this:
--
--    cd <directory where this script enableWarningFlag.sql is saved>
--
--    sqlplus <SCHEMA_LOGIN>/<SCHEMA PASSWORD>@SCHEMA_INSTANCE
--  
--  For example:
--
--    sqlplus pe/PE@BMCPDS
--    
--    SQL> @enableWarningFlag.sql <AIDisplayText> <parameter_name> <Element_Name> <Account> 
--
--  For example:
--
--    SQL> @enableWarningFlag.sql "Process" "Process CPU Utilization" "vm-w23-rds1536" "My Account"
--  If for any of the parameter you want to query all records, provide %% as input for the parameter.
--
--  For example: Following query will look for all accounts and all groups
--
--    SQL> @enableWarningFlag.sql "Process" "Process CPU Utilization" "vm-w23-rds1536" %% %%
--
--  To search or set the alarm or warning threshold for the Application Collection Status
--  parameter, use the root_application_collection_status as the parameterNamePattern.
--  For example: Following query will look for all accounts and all groups
--
--  SQL> @enableWarningFlag.sql "Process" "root_application_collection_status" "vm-w23-rds1536" %% %%
--
--  This will produce enableWarningFlag.html as output of the query.

set echo off;
set termout off;
set trimout on;
set trimspool on;
set pagesize 50000;
set markup html on;
set verify off;
set echo on;
spool test.html;

alter session set nls_date_format='YYYY-MM-DD HH24:MI:SS';

BEGIN
execute immediate 'create table test_current_timeStamp (event_timestamp timestamp)';
EXCEPTION
WHEN OTHERS THEN
null;
END;
/
insert into test_current_timeStamp values(sysdate)
/
select * from test_current_timeStamp
/


spool off;
set echo off;
set termout on;
set markup html off;
exit;