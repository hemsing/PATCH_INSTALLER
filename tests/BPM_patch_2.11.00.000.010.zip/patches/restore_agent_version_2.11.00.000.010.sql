--------------------------------------------------------------------------
-- * BMC Software, Inc.
-- * Confidential and Proprietary
-- * Copyright (c) BMC Software, Inc. 2015
-- * All Rights Reserved.
--------------------------------------------------------------------------
set linesize 500;
set head off;
set trimspool on;
set feedback on;
WHENEVER SQLERROR EXIT;
set termout on;
spool restore_agent_version_2.11.00.000.010.log;
select count(*) from agent_patch_storage_11_010
/
select count(*) from agent_patch_info_11_010
/
select count(*) from agent_11_010
/

delete from agent_patch_storage
/
delete from agent_patch_info
/
insert into agent_patch_info select * from agent_patch_info_11_010
/
insert into agent_patch_storage select * from agent_patch_storage_11_010
/

update agent a set PATCHVERSION=(select PATCHVERSION from agent_11_010 b where b.guid=a.guid)
/
update agent a set patchstatus=(select PATCHSTATUS from agent_11_010 b where b.guid=a.guid)
/

drop table agent_patch_info_11_010
/
drop table agent_patch_storage_11_010
/

drop table agent_11_010
/

commit;

spool off;
set termout on;
prompt ===========================
prompt 
prompt Restore completed successfully.
prompt ===========================
prompt 
exit;