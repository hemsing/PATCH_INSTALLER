Copyright (c) 2016 BMC Software, Inc.

Product		:  BMC Performance Manager Portal
Patch Version	:  Hotfix 2.11.00.000.010
Released Date	:  19-Apr-2016


============================================================================================

Defects Addressed:

QM001822669: Remote Service Monitor(RSM) thread gets blocked due to the Perfmon collector native calls.

QM001869437: After a failure to connect to the remote registry the application should retry the connection, instead of reporting a failure.

QM001774677: Problem collecting metrics for 32-bit ASP.NET Applications running on Windows 64-bit 2010 R2 Servers. Added support to monitor Perfmon objects which have both 32-bit/64-bit Perfmon counters on a 64-bit system.

QM001864154: If a timeout occurs when monitoring Windows servers, the connection is kept in the pending queue and then the connection remains in the pending queue indefinitely.

QM001804786: If a Windows Server is rebooted while being monitored, the Application Collection Status will go into alarm and will never restart monitoring until the element is turned off/on or the TTL connection expires.

QM001877356: Custom SSH collector solutions are not showing the SSH command in the edit screens when the performance manager is being edited via the Performance Manager Editor.

QM001878016: Portal 2.11 failed to recognize 2.10.01 SDK as a valid SDK.

QM001881608: Remote Service Monitor was not able to collect data and displayed the following error in the rsm.log file:
		e=java.lang.IllegalStateException: BadPaddingException exception during decryption

QM001891153: Found vulnerability in the Apache Commons Library deserialization vulnerability. https://issues.apache.org/jira/browse/COLLECTIONS-580

RFEs Addressed:

QM001863010: Ability to turn elements or groups monitoring ON or OFF using the BPMCLI
QM001994727: Ability to work with NTLM users using the "Send NTLMv2 response only. Refuse LM & NTLM" authentication protocol.


============================================================================================

Patch Description

This Patch is applicable to BMC Performance Manager Portal and BMC RSM 2.11.00. 
It is cumulative, that is, it includes the fixes for the previous RSM and Portal defects as well. 
The portal patch is specific to the QM001877356 and QM001878016, QM001891153 defects and QM001863010 RFE also. 
(need a space after the comma right before QM001891153)

To edit an existing custom solution for SSH collector class, run the following steps:
      1. Edit every custom solution using the SSH collector.
      2. If the SSH command is displayed as blank, enter the correct command.
      3. Save and Publish the modified solution.



============================================================================================
Platforms Supported:

All platforms supported by BMC Performance Manager Portal.

============================================================================================
Base Product Version:

2.11.00

============================================================================================

Dependency:

BMC PM Portal 2.11.00

============================================================================================

Files Installed:

Windows:
%BMC_PORTAL_KIT_HOME%\patches\RSM_Patch_Files_2.11.00.000.010.jar
%BMC_PORTAL_KIT_HOME%\patches\backup_agent_version_2.11.00.000.010.sql
%BMC_PORTAL_KIT_HOME%\patches\readme_2.11.00.000.010.txt
%BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\BPM_patch_2.11.00.000.010-service.xml
%BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\admin-console.war\WEB-INF\lib\commons-collections-3.2.2.jar
%BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\websdk.sar\lib\jcifs-1.3.18.jar
%BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\common\lib\commons-collections-3.2.2.jar
%BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\lib\patsdk-impl-2.11.00.000.005.jar
%BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\lib\patsdk-application-class-editor-2.11.00.000.004.jar
%BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\drmop-ws25.war
%BMC_PORTAL_KIT_HOME%\appserver\util\BPM_CLI\bpmcli.jar


Solaris:
$BMC_PORTAL_KIT_HOME/patches/RSM_Patch_Files_2.11.00.000.010.jar
$BMC_PORTAL_KIT_HOME/patches/backup_agent_version_2.11.00.000.010.sql
$BMC_PORTAL_KIT_HOME/patches/readme_2.11.00.000.010.txt
$BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/BPM_patch_2.11.00.000.010-service.xml
$BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/admin-console.war/WEB-INF/lib/commons-collections-3.2.2.jar
$BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/websdk.sar/lib/jcifs-1.3.18.jar
$BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/common/lib/commons-collections-3.2.2.jar
$BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/lib/patsdk-impl-2.11.00.000.005.jar
$BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/lib/patsdk-application-class-editor-2.11.00.000.004.jar
$BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/drmop-ws25.war
$BMC_PORTAL_KIT_HOME/appserver/util/BPM_CLI/bpmcli.jar

==================================================================================
Before you install:

Back up the contents of the following files to a different drive:
	
	On a Windows Server: 
	a) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\lib\patsdk-application-class-editor-*.jar and patsdk-impl-*.jar
	b) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\admin-console.war\WEB-INF\lib\commons-collections-3.2.jar
	c) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\common\lib\commons-collections.jar
	d) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\websdk.sar\lib\jcifs-0.8.3.jar


	On a Solaris Server: 
	a) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/lib/patsdk-application-class-editor-*.jar and patsdk-impl-*.jar
	where BMC_PORTAL_KIT_HOME is an environment variable defined with the path of the BMC Portal installation directory.
	b) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/admin-console.war/WEB-INF/lib/commons-collections-3.2.jar
	c) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/common/lib/commons-collections.jar
	d) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/websdk.sar/lib/jcifs-0.8.3.jar


============================================================================================

Patch Installation:

1) Stop the BMC Portal Application Server service and the BMC Portal Webserver service.

2) Delete the following files from the application server:

	On a Windows Server: 
	a) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\lib\patsdk-application-class-editor-*.jar
	b) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\lib\patsdk-impl-*.jar
	c) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\admin-console.war\WEB-INF\lib\commons-collections-3.2.jar
	d) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\common\lib\commons-collections.jar
	e) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\websdk.sar\lib\jcifs-0.8.3.jar
	
	On a Solaris Server: 
	a) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/lib/patsdk-application-class-editor-*.jar
	b) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/lib/patsdk-impl-*.jar 
	c) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/admin-console.war/WEB-INF/lib/commons-collections-3.2.jar
	d) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/common/lib/commons-collections.jar
	e) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/websdk.sar/lib/jcifs-0.8.3.jar

3) Extract the contents of the BPM_patch_2.11.00.000.010.zip file to the following directory:
        a) On a Windows server: %BMC_PORTAL_KIT_HOME%
        b) On a UNIX server: $BMC_PORTAL_KIT_HOME


4) Ensure that the installation files are placed in the appropriate directory as mentioned in the "Files installed" section.

5) Copy the %BMC_PORTAL_KIT_HOME%\patches\backup_agent_version_2.11.00.000.010.sql file to the Portal database server.

6) Log in to the Portal database and run the following SQL:

sqlplus pe/pe@Bmcpds @backup_agent_version_2.11.00.000.010.sql

7) Copy the restore_agent_version_2.11.00.000.010.sql file to the 
%BMC_PORTAL_KIT_HOME%\patches folder. You will need this file if you might want to rollback the patch.

8) Start the BMC Portal Application Server service and the BMC Portal Webserver service.

9) If you have a clustered environment, repeat steps 1 to 5 on the secondary application server.

10) Log in to the Portal User Interface as an end user.

11) Navigate to the Configure tab, select the "About" option to display the About page and confirm that patch version 2.11.00.000.010 is listed.

12) Log in to the Portal User Interface as the 'superadmin' user.

13) Click the Portal tab and select the 'Remote Service Monitors' option.

14) Click the 'Upload Patch' button and browse to the %BMC_PORTAL_KIT_HOME%\patches or $BMC_PORTAL_KIT_HOME/patches directory where the 'RSM_Patch_Files_2.11.00.000.010.jar' is located, select the file and upload it.

15) Once the patch is uploaded, select the RSM machine entries from the table for which you want to apply the patch and click the 'Apply Patch' button. The RSM patch will be pushed to the RSM servers. It might take some time to apply the patch to each RSM.
(Note: The patch can be applied to a maximum of 4 RSMs at a time. Follow the same steps for all additional RSM servers.)

If the Portal reports a version incompatibility error when attempting to apply the patch, use the following steps to fix the issue 

		1) Log in to the Portal database as sqlplus pe/pe@bmcpds
		2) Run the following SQL statements:
			delete from agent_patch_storage ;
			delete from agent_patch_info ;
			update agent set patchstatus='AVAILABLE';
			update agent set patchversion='2.11.00';
			commit;

		3) Repeat steps 14 and 15 to apply the 2.11.00.000.010 patch on the RSM



16) Allow some time for the patch to be applied on each of the RSMs. After successful application, the RSM patch version is displayed as 2.11.00.000.010 in the 'Remote Service Monitors' list.

17) Verify that all RSMs are communicating with the Portal. Log in to the Portal as superadmin, select the Configure tab and then the 'Remote Service Monitors' option, and verify the status is green for each RSM via the Portal User Interface.

18) If you are using the BPMCLI (BPM command line interface, that is, bpmcli.bat or bpmcli.sh) from another location than the  application server, copy and replace the bpmcli.jar file located at BMC_PORTAL_KIT_HOME/appserver/util/BPM_CLI/ with the one located at another location

==================================================================================
RFE description:

QM001863010: Ability to turn elements or groups monitoring  ON/OFF through the BPMCLI

This enhancement provides the functionality that enables you to turn monitoring on or off for either elements or groups using the BPMCLI. You can use the BPMCLI with Windows or Solaris schedulers so that the required hosts will have monitoring turned off at the particular scheduled time and will resume monitoring at the scheduled time. 

The following new commands have been added to achieve this functionality:

monitorElementsOn: To turn monitoring on for elements or groups
monitorElementsOff: To turn monitoring off for elements or groups

You can run these commands for the following options:

a.	To monitor on/off single element 
For example, bpmcli -portal clm-pun-012345.bmc.com  -login user -pass user -c monitorElementsOff -e Element_test1
b.	To monitor on/off single group
For example, bpmcli -portal clm-pun-012345.bmc.com  -login user -pass user -c monitorElementsOff -g Test_Group1
c.	To monitor on/off list of elements or list of groups using a csv file.
For example, bpmcli -portal clm-pun-012345.bmc.com  -login user -pass user -c monitorElementsOff -f monitor_Test.csv

The csv file must have the entries in the following format:
For a list of elements, the format should be:

		<elementName>,
		<elementName>,

	For example, 
		Element_test1,
		Element_test2,

For a list of groups, the format should be:

		,<GroupName>
		,<GroupName>

	For example,
		,Test_Group1
		,Test_Group

For a list of elements and groups, the format should be:
                <elementName>,<GroupName>
                <elementName>,<GroupName>

	For example,
                Element_test1,Test_Group1
		Element_test2,Test_Group2

============================================================================================

Patch Uninstallation:

1) Stop the BMC Portal Application Server service and BMC Portal Webserver service.

2) Log in to the RSM Server.

3) Navigate to the <Installation Directory>\Remote Service Monitor\rsmBackup\backup_pre_rsmPatch_2.11.00.000.010 folder using the command prompt.

4) Run the restorePatch.bat batch file. It displays the following output after successful completion:

Patch restored successfully.
Starting BMC Remote Service Monitor Service.

For example, run the following command in the command prompt:

		C:\>cd C:\BMCSoftware\Remote Service Monitor\rsmBackup\backup_pre_rsmPatch_2.11.00.000.010
		C:\BMCSoftware\Remote Service Monitor\rsmBackup\backup_pre_rsmPatch_2.11.00.000.010>restorePatch.bat
			
		It displays the following output after successful completion.

			Patch restored successfully.
			Starting BMC Remote Service Monitor Service.

5) Repeat the steps 2,3,4 for all RSMs from which you want to unistall this patch.

6) Navigate to the Portal Database server.

7) Copy the restore_agent_version_2.11.00.000.010.sql file mentioned in the step no 7 of the "Patch Installation" section, to the Portal database server.

8) Log in to the Portal database and run the following script:
sqlplus pe/pe@bmcpds
@restore_agent_version_2.11.00.000.010.sql


9) The script generates the restore_agent_version_2.11.00.000.010.log file. Save the file to the %BMC_PORTAL_KIT_HOME%\patches directory.

10) Delete the following files:

               On a Windows server: 
               a) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\BPM_patch_2.11.00.000.010-service.xml
               b) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\lib\patsdk-application-class-editor-2.11.00.000.004.jar 
               c) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\lib\patsdk-impl-2.11.00.000.005.jar
	       d) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\websdk.sar\lib\jcifs-1.3.18.jar
               
               On a Solaris server: 
               a) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/BPM_patch_2.11.00.000.010-service.xml
               b) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/lib/patsdk-application-class-editor-2.11.00.000.004.jar 
               c) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/lib/patsdk-impl-2.11.00.000.005.jar
	       d) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/websdk.sar/lib/jcifs-1.3.18.jar

11) From the backup folder created in the "Before you install" section, copy the patsdk-application-class-editor-*.jar,patsdk-impl-*.jar,commons-collections-3.2.jar,commons-collections.jar files to the following directories: 
		On a Windows server:
              a) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\lib\patsdk-application-class-editor-*.jar
	      b) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\modules\drmop.sar\lib\patsdk-impl-*.jar
	      c) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\server\all\deploy\admin-console.war\WEB-INF\lib\commons-collections-3.2.jar
	      d) %BMC_PORTAL_KIT_HOME%\appserver\websdk\tools\jboss\common\lib\commons-collections.jar


              On a Solaris server:
              a) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/lib/patsdk-application-class-editor-*.jar
	      b) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/modules/drmop.sar/lib/patsdk-impl-*.jar 
	      c) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/server/all/deploy/admin-console.war/WEB-INF/lib/commons-collections-3.2.jar
	      d) $BMC_PORTAL_KIT_HOME/appserver/websdk/tools/jboss/common/lib/commons-collections.jar
		 
		 where BMC_PORTAL_KIT_HOME is an environment variable defined with the path of the BMC Portal installation directory.

12) If you have a clustered environment, repeat steps 10 and 11 on the secondary application server.

13) Start the BMC Portal Web Server service and the BMC Portal Application Server service.

14) Log in to the Portal User Interface as 'superadmin'. Select the Configure tab and the 'Remote Service Monitors' option. Verify that the RSM Patch version displays the previous patch verion.


============================================================================================

Notes:

1. Patches contain information for RFE's/Defect's requested by the customers.
This Patch has been unit tested by development and has undergone QA certification for fresh deployment.

2. If you experience a problem after implementing this patch, remove it and reinstate the original installation, which was backed up as per the Pre-Installation instructions.  
If problem persists, then contact BMC Support. 

============================================================================================